local BasePlugin = require "kong.plugins.base_plugin"
local IntoHandler = BasePlugin:extend()


function IntoHandler:new()
  IntoHandler.super.new(self, "iqsuite-introspection")
end

function IntoHandler:access(config)
  IntoHandler.super.access(self)
  local introConfig = get_options(config, ngx)
  ngx.log(ngx.DEBUG, "IntoHandler ignoring request, path: " .. ngx.var.request_uri)
  introspec(introConfig)
  ngx.log(ngx.DEBUG, "IntoHandler done")
end



function introspec(introConfig)

  if not has_bearer_access_token() then
   exit(ngx.HTTP_BAD_REQUEST, '{"error":"bad_request","error_description":"Bearer token is missing"}', ngx.HTTP_BAD_REQUEST)
   return nil
  end

  if has_bearer_access_token() then
    local res, err = require("resty.openidc").introspect(introConfig)
    if err then
        ngx.header["WWW-Authenticate"] = 'Bearer error="' .. err .. '"'
        exit(ngx.HTTP_UNAUTHORIZED, '{"error":"access_denied","error_description":"The resource owner or authorization server denied the request."}', ngx.HTTP_UNAUTHORIZED)
      return nil
    end
   ngx.log(ngx.DEBUG, "IntoHandler introspect succeeded, requested path: " .. ngx.var.request_uri)
   return res
  end
end

function has_bearer_access_token()
  local header = ngx.req.get_headers()['Authorization']
  if header and header:find(" ") then
    local divider = header:find(' ')
    if string.lower(header:sub(0, divider-1)) == string.lower("Bearer") then
      return true
    end
  end
  return false
end

function get_options(config, ngx)
  return {

    introspection_endpoint = config.introspection_endpoint,
    ssl_verify = config.ssl_verify,
    introspection_params = { scope = "openid uma_protection" }
  }
end

function exit(httpStatusCode, message, ngxCode)
  ngx.status = httpStatusCode
  ngx.say(message)
  ngx.exit(ngxCode)
end

return IntoHandler
